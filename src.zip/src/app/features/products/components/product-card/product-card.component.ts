// src/app/features/products/components/product-card/product-card.component.ts
import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Product } from '../../../../shared/models/product.model';
import { LucideAngularModule } from 'lucide-angular';
import { CartService } from '../../../../core/services/cart.service';
import { FavoritesService } from '../../../../core/services/favorites.service';
import { Subscription } from 'rxjs';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [
    CommonModule, 
    LucideAngularModule
  ],
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.css'],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]  // Add this line

})
export class ProductCardComponent implements OnInit, OnDestroy {
  @Input() product: Product | null = null;
  isFavorite = false;
  readonly Math = Math; // Make Math available in template

  // Icons object to use in template
  icons = {
    heart: 'heart',
    cart: 'shopping-cart',
    star: 'star',
    x: 'x'
  };

  private favoritesSubscription: Subscription | null = null;

  constructor(
    private cartService: CartService,
    private favoritesService: FavoritesService
  ) {}

  ngOnInit(): void {
    if (this.product) {
      this.isFavorite = this.favoritesService.isFavorite(this.product.id);
    }
    // Subscribe to favorites changes to keep the UI in sync
    this.favoritesSubscription = this.favoritesService.favorites$.subscribe(favorites => {
      if (this.product) {
        this.isFavorite = favorites.some(p => p.id === this.product?.id);
      }
    });
  }

  ngOnDestroy(): void {
    // Clean up subscription to prevent memory leaks
    if (this.favoritesSubscription) {
      this.favoritesSubscription.unsubscribe();
    }
  }

  handleImageError(event: Event): void {
    const imgElement = event.target as HTMLImageElement;
    // Set a fallback image or hide the image on error
    imgElement.style.display = 'none';
    console.warn('Image failed to load:', imgElement.src);
  }

  getStars(count: number): number[] {
    return Array(count).fill(0).map((_, i) => i);
  }

  addToCart(event: Event): void {
    event.stopPropagation();
    if (this.product) {
      this.cartService.addToCart(this.product);
    }
  }

  toggleFavorite(event: Event): void {
    event.stopPropagation();
    if (!this.product) return;

    // Optimistically update the UI
    this.isFavorite = !this.isFavorite;
    
    if (this.isFavorite) {
      // Assuming addToFavorites returns void, not an Observable
      this.favoritesService.addToFavorites(this.product as any);
    } else {
      this.favoritesService.removeFromFavorites(this.product.id).subscribe({
        error: (error: any) => {
          console.error('Error removing from favorites:', error);
          // Revert the UI if there's an error
          this.isFavorite = !this.isFavorite;
        }
      });
    }
  }
}