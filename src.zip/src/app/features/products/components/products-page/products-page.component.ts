import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LucideAngularModule, Filter, ArrowUpDown } from 'lucide-angular';
import { ProductsService } from '../../../../core/services/products.service';
import { ProductCardComponent } from '../product-card/product-card.component';
import { Product } from '../../../../features/shared/models/product.model';

@Component({
  selector: 'app-products-page',
  standalone: true,
  imports: [CommonModule, ProductCardComponent, LucideAngularModule],
  templateUrl: './products-page.component.html',
  styleUrls: ['./products-page.component.css']
})
export class ProductsPageComponent implements OnInit {
  allProducts: Product[] = [];

  // Icons
  icons = {
    filter: Filter,
    sort: ArrowUpDown
  };

  constructor(
    private productsService: ProductsService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.loadProducts();
  }

  private loadProducts(): void {
    this.productsService.getProducts().subscribe({
      next: (products) => {
        this.allProducts = products;
        this.cdr.markForCheck();
      },
      error: (error) => {
        console.error('Error loading products:', error);
        this.allProducts = [];
        this.cdr.markForCheck();
      }
    });
  }
}