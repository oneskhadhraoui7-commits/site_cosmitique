import { Routes } from '@angular/router';
import { FavoritesPageComponent } from './components/favorites-page/favorites-page.component';

export const FavoritesRoutes: Routes = [
  { path: 'favorites', component: FavoritesPageComponent }
];
