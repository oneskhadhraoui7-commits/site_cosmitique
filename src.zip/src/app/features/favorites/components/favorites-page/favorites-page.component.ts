import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ProductCardComponent } from '../../../products/components/product-card/product-card.component';
import { FavoritesService } from '../../../../core/services/favorites.service';
import { Product } from '../../../shared/models/product.model';

@Component({
  selector: 'app-favorites-page',
  standalone: true,
  imports: [CommonModule, RouterLink, ProductCardComponent],
  template: `
    <div class="container mx-auto px-4 py-12">
      <div class="max-w-7xl mx-auto">
        <div class="flex items-center justify-between mb-8">
          <h1 class="text-3xl font-bold text-gray-900">Mes favoris</h1>
          <p class="text-gray-600">
            {{ favoritesCount }} {{ favoritesCount === 1 ? 'article' : 'articles' }}
          </p>
        </div>

        <div *ngIf="favorites.length > 0; else emptyState" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <div *ngFor="let product of favorites" class="relative">
            <button 
              (click)="removeFromFavorites(product.id)" 
              class="absolute top-2 right-2 z-10 p-2 rounded-full bg-white/80 hover:bg-gray-100 transition-colors duration-200"
              [attr.aria-label]="'Retirer ' + product.name + ' des favoris'"
            >
              <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-pink-500" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clip-rule="evenodd" />
              </svg>
            </button>
            <app-product-card [product]="product"></app-product-card>
          </div>
        </div>

        <ng-template #emptyState>
          <div class="text-center py-12">
            <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
            <h3 class="mt-2 text-lg font-medium text-gray-900">Aucun favori</h3>
            <p class="mt-1 text-gray-500">Ajoutez des produits à vos favoris pour les retrouver facilement plus tard.</p>
            <div class="mt-6">
              <a routerLink="/products" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-pink-600 hover:bg-pink-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500">
                Parcourir les produits
              </a>
            </div>
          </div>
        </ng-template>
      </div>
    </div>
  `,
  styles: []
})
export class FavoritesPageComponent {
  favorites: Product[] = [];
  favoritesCount = 0;

  constructor(private favoritesService: FavoritesService) {
    this.favoritesService.favorites$.subscribe(favorites => {
      this.favorites = favorites;
      this.favoritesCount = favorites.length;
    });
  }

  removeFromFavorites(productId: string): void {
    this.favoritesService.removeFromFavorites(productId);
  }
}
