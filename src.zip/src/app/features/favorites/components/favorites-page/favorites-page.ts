// favorites-page.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FavoritesService } from '../../../../core/services/favorites.service';
import { Product } from '../../../../shared/models/product.model';
import { ProductCardComponent } from '../../../products/components/product-card/product-card.component';

@Component({
  selector: 'app-favorites-page',
  standalone: true,
  imports: [CommonModule, ProductCardComponent],
  template: `
    <div class="container mx-auto px-4 py-8">
      <h1 class="text-3xl font-bold mb-8">My Favorites</h1>
      
      <div *ngIf="isLoading" class="text-center py-8">
        <p>Loading favorites...</p>
      </div>

      <div *ngIf="!isLoading && favorites.length === 0" class="text-center py-8">
        <p class="text-gray-500">You don't have any favorite products yet.</p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <app-product-card 
          *ngFor="let product of favorites" 
          [product]="product"
          (favoriteToggled)="onFavoriteToggled($event)">
        </app-product-card>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      min-height: 70vh;
    }
  `]
})
export class FavoritesPage implements OnInit {
  favorites: Product[] = [];
  isLoading = true;

  constructor(private favoritesService: FavoritesService) {}

  ngOnInit() {
    this.loadFavorites();
  }

  private loadFavorites() {
    this.isLoading = true;
    this.favoritesService.favorites$.subscribe({
      next: (favorites) => {
        this.favorites = favorites || [];
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading favorites:', error);
        this.isLoading = false;
      }
    });
  }

  onFavoriteToggled(event: Event) {
    // Extract the product from the custom event
    const customEvent = event as CustomEvent;
    const product = customEvent.detail as Product;
    
    // Update the local state
    this.favorites = this.favorites.filter(p => p.id !== product.id);
  }
}