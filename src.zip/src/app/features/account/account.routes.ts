import { Routes } from '@angular/router';
import { AccountPageComponent } from './components/account-page/account-page.component';

export const AccountRoutes: Routes = [
  { path: 'account', component: AccountPageComponent }
];
