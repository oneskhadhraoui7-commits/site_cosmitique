import { Component } from '@angular/core';
import { AuthService } from '../../../../core/services/auth.service';
import { Observable } from 'rxjs';
import { User } from '../../../shared/models/user.model';
import { AsyncPipe, DatePipe } from '@angular/common';

@Component({
  selector: 'app-account-page',
  standalone: true,
  imports: [AsyncPipe, DatePipe],
  template: `
    <div class="container mx-auto px-4 py-12">
      <div class="max-w-4xl mx-auto">
        <h1 class="text-3xl font-bold text-gray-900 mb-8">Mon compte</h1>
        
        <div class="bg-white shadow overflow-hidden sm:rounded-lg">
          <div class="px-4 py-5 sm:px-6">
            <h2 class="text-lg leading-6 font-medium text-gray-900">Informations du compte</h2>
            <p class="mt-1 max-w-2xl text-sm text-gray-500">Détails personnels et préférences.</p>
          </div>
          <div class="border-t border-gray-200 px-4 py-5 sm:p-0">
            <dl class="sm:divide-y sm:divide-gray-200">
              <div class="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt class="text-sm font-medium text-gray-500">Nom complet</dt>
                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                  {{ (user$ | async)?.name || 'Non défini' }}
                </dd>
              </div>
              <div class="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt class="text-sm font-medium text-gray-500">Adresse email</dt>
                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                  {{ (user$ | async)?.email || 'Non défini' }}
                </dd>
              </div>
              <div class="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt class="text-sm font-medium text-gray-500">Membre depuis</dt>
                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                  {{ (user$ | async)?.createdAt ? ((user$ | async)?.createdAt | date:'mediumDate') : 'Non disponible' }}
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: []
})
export class AccountPageComponent {
  user$: Observable<User | null>;
  
  constructor(private authService: AuthService) {
    this.user$ = this.authService.user$;
  }
}
