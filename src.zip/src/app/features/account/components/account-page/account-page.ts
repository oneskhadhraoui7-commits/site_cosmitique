import { Component } from '@angular/core';

@Component({
  selector: 'app-account-page',
  imports: [],
  template: `
    <p>
      account-page works!
    </p>
  `,
  styles: ``,
})
export class AccountPage {

}
