import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AdminRoutes } from './admin.routes';
import { AdminService } from '../../core/services/admin.service';
import { AdminGuard } from '../../core/guards/admin.guard';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminRoutes)
  ],
  providers: [
    AdminService,
    AdminGuard
  ]
})
export class AdminModule { }