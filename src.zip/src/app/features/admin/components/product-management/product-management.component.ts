import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../../environments/environment';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  category: string;
}

@Component({
  selector: 'app-product-management',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    CurrencyPipe
  ],
  template: `
    <div class="product-management">
      <h2>Product Management</h2>
      
      <div class="add-product-form">
        <h3>Add New Product</h3>
        <form [formGroup]="productForm" (ngSubmit)="onSubmit()">
          <div class="form-group">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Product Name</mat-label>
              <input matInput formControlName="name" required>
            </mat-form-field>
          </div>
          
          <div class="form-group">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Price</mat-label>
              <input matInput type="number" formControlName="price" required min="0" step="0.01">
            </mat-form-field>
          </div>
          
          <div class="form-group">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Description</mat-label>
              <textarea matInput formControlName="description" rows="3" required></textarea>
            </mat-form-field>
          </div>
          
          <div class="form-group">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Image URL</mat-label>
              <input matInput formControlName="image" required>
            </mat-form-field>
          </div>
          
          <div class="form-group">
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Category</mat-label>
              <mat-select formControlName="category" required>
                <mat-option *ngFor="let category of categories" [value]="category">
                  {{ category }}
                </mat-option>
              </mat-select>
            </mat-form-field>
          </div>
          
          <div class="form-actions">
            <button mat-raised-button color="primary" type="submit" [disabled]="!productForm.valid">
              {{ editingProduct ? 'Update' : 'Add' }} Product
            </button>
            <button mat-button type="button" (click)="cancelEdit()" *ngIf="editingProduct">
              Cancel
            </button>
          </div>
        </form>
      </div>
      
      <div class="product-list">
        <h3>Existing Products</h3>
        <table mat-table [dataSource]="products" class="mat-elevation-z2">
          <!-- Name Column -->
          <ng-container matColumnDef="name">
            <th mat-header-cell *matHeaderCellDef>Name</th>
            <td mat-cell *matCellDef="let product">{{ product.name }}</td>
          </ng-container>
          
          <!-- Price Column -->
          <ng-container matColumnDef="price">
            <th mat-header-cell *matHeaderCellDef>Price</th>
            <td mat-cell *matCellDef="let product">{{ product.price | currency }}</td>
          </ng-container>
          
          <!-- Category Column -->
          <ng-container matColumnDef="category">
            <th mat-header-cell *matHeaderCellDef>Category</th>
            <td mat-cell *matCellDef="let product">{{ product.category }}</td>
          </ng-container>
          
          <!-- Actions Column -->
          <ng-container matColumnDef="actions">
            <th mat-header-cell *matHeaderCellDef>Actions</th>
            <td mat-cell *matCellDef="let product">
              <button mat-icon-button color="primary" (click)="editProduct(product)">
                <mat-icon>edit</mat-icon>
              </button>
              <button mat-icon-button color="warn" (click)="deleteProduct(product.id)">
                <mat-icon>delete</mat-icon>
              </button>
            </td>
          </ng-container>
          
          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .product-management {
      padding: 20px;
    }
    .add-product-form {
      margin-bottom: 30px;
      padding: 20px;
      background: #f5f5f5;
      border-radius: 4px;
    }
    .form-group {
      margin-bottom: 15px;
    }
    .full-width {
      width: 100%;
    }
    .form-actions {
      display: flex;
      gap: 10px;
      margin-top: 20px;
    }
    .product-list {
      margin-top: 30px;
    }
    table {
      width: 100%;
    }
  `]
})
export class ProductManagementComponent implements OnInit {
  productForm: FormGroup;
  products: Product[] = [];
  editingProduct: Product | null = null;
  categories = ['skincare', 'makeup', 'haircare', 'fragrance'];
  displayedColumns: string[] = ['name', 'price', 'category', 'actions'];
  private apiUrl = environment.apiUrl;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient
  ) {
    this.productForm = this.fb.group({
      name: ['', Validators.required],
      price: [0, [Validators.required, Validators.min(0.01)]],
      description: ['', Validators.required],
      image: ['', Validators.required],
      category: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(): void {
    this.http.get<Product[]>(`${this.apiUrl}/products`).subscribe({
      next: (products) => {
        this.products = products;
      },
      error: (error) => {
        console.error('Error loading products:', error);
      }
    });
  }

  onSubmit(): void {
    if (this.productForm.invalid) return;

    const productData = this.productForm.value;
    
    if (this.editingProduct) {
      // Update existing product
      this.http.put(`${this.apiUrl}/products/${this.editingProduct.id}`, productData)
        .subscribe({
          next: () => {
            this.loadProducts();
            this.cancelEdit();
          },
          error: (error) => {
            console.error('Error updating product:', error);
          }
        });
    } else {
      // Add new product
      this.http.post(`${this.apiUrl}/products`, productData)
        .subscribe({
          next: () => {
            this.loadProducts();
            this.productForm.reset();
          },
          error: (error) => {
            console.error('Error adding product:', error);
          }
        });
    }
  }

  editProduct(product: Product): void {
    this.editingProduct = { ...product };
    this.productForm.patchValue({
      name: product.name,
      price: product.price,
      description: product.description,
      image: product.image,
      category: product.category
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  deleteProduct(id: string): void {
    if (confirm('Are you sure you want to delete this product?')) {
      this.http.delete(`${this.apiUrl}/products/${id}`)
        .subscribe({
          next: () => {
            this.loadProducts();
          },
          error: (error) => {
            console.error('Error deleting product:', error);
          }
        });
    }
  }

  cancelEdit(): void {
    this.editingProduct = null;
    this.productForm.reset();
  }
}
