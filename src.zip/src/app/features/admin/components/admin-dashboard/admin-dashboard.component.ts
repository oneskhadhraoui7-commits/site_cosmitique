// admin-dashboard.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AdminService } from '../../../../core/services/admin.service';
import { Subscription } from 'rxjs';
import { MaterialModule } from '../../../../shared/material.module';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule
  ],
  template: `
    <div class="admin-container">
      <mat-sidenav-container class="sidenav-container">
        <mat-sidenav #sidenav mode="side" opened>
          <div class="sidenav-header">
            <h2>Admin Panel</h2>
          </div>
          <mat-nav-list>
            <a mat-list-item routerLink="/admin/dashboard" routerLinkActive="active" (click)="sidenav.close()">
              <mat-icon>dashboard</mat-icon>
              <span>Dashboard</span>
            </a>
            <a mat-list-item routerLink="/admin/products" routerLinkActive="active" (click)="sidenav.close()">
              <mat-icon>shopping_bag</mat-icon>
              <span>Product Management</span>
            </a>
            <a mat-list-item routerLink="/admin/orders" routerLinkActive="active" (click)="sidenav.close()">
              <mat-icon>receipt</mat-icon>
              <span>Orders</span>
            </a>
            <a mat-list-item (click)="logout()">
              <mat-icon>logout</mat-icon>
              <span>Logout</span>
            </a>
          </mat-nav-list>
        </mat-sidenav>

        <mat-sidenav-content>
          <mat-toolbar color="primary" class="admin-toolbar">
            <div class="toolbar-left">
              <button mat-icon-button (click)="sidenav.toggle()" class="menu-button">
                <mat-icon>menu</mat-icon>
              </button>
              <a routerLink="/admin/dashboard" class="logo-link">
                <h1>Admin Dashboard</h1>
              </a>
            </div>
            
            <div class="toolbar-center">
              <nav class="nav-links">
                <a mat-button routerLink="/admin/dashboard" routerLinkActive="active-link" [routerLinkActiveOptions]="{exact: true}">
                  <mat-icon>dashboard</mat-icon>
                  <span>Dashboard</span>
                </a>
                <a mat-button routerLink="/admin/products" routerLinkActive="active-link">
                  <mat-icon>inventory_2</mat-icon>
                  <span>Products</span>
                </a>
                <a mat-button routerLink="/admin/orders" routerLinkActive="active-link">
                  <mat-icon>receipt_long</mat-icon>
                  <span>Orders</span>
                </a>
              </nav>
            </div>
            
            <div class="toolbar-right">
              <button mat-icon-button [matMenuTriggerFor]="userMenu" class="user-menu-button" matTooltip="User menu">
                <mat-icon>account_circle</mat-icon>
              </button>
              
              <mat-menu #userMenu="matMenu">
                <button mat-menu-item (click)="logout()">
                  <mat-icon>logout</mat-icon>
                  <span>Logout</span>
                </button>
              </mat-menu>
            </div>
          </mat-toolbar>

          <div class="content">
            <div *ngIf="!isAdmin" class="unauthorized">
              <p>You don't have permission to access this page.</p>
              <button mat-raised-button color="primary" (click)="navigateToLogin()">Go to Login</button>
            </div>
            <div *ngIf="isAdmin" class="admin-content">
              <router-outlet></router-outlet>
              <div *ngIf="router.url === '/admin/dashboard' || router.url === '/admin'">
                <div class="dashboard-cards">
                  <mat-card class="dashboard-card">
                    <mat-card-header>
                      <mat-card-title>Welcome to Admin Dashboard</mat-card-title>
                    </mat-card-header>
                    <mat-card-content>
                      <p>Manage your store's products, orders, and settings from here.</p>
                    </mat-card-content>
                  </mat-card>
                </div>
              </div>
            </div>
          </div>
        </mat-sidenav-content>
      </mat-sidenav-container>
    </div>
  `,
  styles: [`
    /* Admin Toolbar Styles */
    .admin-toolbar {
      position: sticky;
      top: 0;
      z-index: 2;
      display: flex;
      justify-content: space-between;
      padding: 0 16px;
      height: 64px;
    }
    
    .toolbar-left, .toolbar-center, .toolbar-right {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    
    .toolbar-center {
      flex: 1;
      justify-content: center;
    }
    
    .nav-links {
      display: flex;
      gap: 8px;
      
      a {
        color: white;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 16px;
        border-radius: 4px;
        transition: background-color 0.2s;
        
        &:hover {
          background-color: rgba(255, 255, 255, 0.1);
        }
        
        &.active-link {
          background-color: rgba(255, 255, 255, 0.2);
          font-weight: 500;
        }
        
        mat-icon {
          margin-right: 4px;
        }
      }
    }
    
    .logo-link {
      color: white;
      text-decoration: none;
      display: flex;
      align-items: center;
    }
    
    .logo-link h1 {
      font-size: 1.25rem;
      font-weight: 500;
      margin: 0;
      line-height: 1.5;
    }
    
    .user-menu-button {
      color: white;
    }
    
    .spacer {
      flex: 1 1 auto;
    }
    
    .admin-container {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
    }
    
    .sidenav-container {
      height: 100%;
    }
    
    .sidenav-header {
      padding: 16px;
      text-align: center;
      background-color: #3f51b5;
      color: white;
    }
    
    .sidenav-header h2 {
      margin: 0;
      font-size: 1.2rem;
    }
    
    mat-sidenav {
      width: 250px;
      background-color: #f5f5f5;
      box-shadow: 3px 0 6px rgba(0,0,0,0.24);
    }
    
    .content {
      padding: 20px;
      min-height: calc(100vh - 64px);
      background-color: #fafafa;
    }
    
    .spacer {
      flex: 1 1 auto;
    }
    
    .unauthorized {
      text-align: center;
      margin-top: 50px;
    }
    
    .dashboard-cards {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }
    
    .dashboard-card {
      margin-bottom: 20px;
    }
    
    mat-nav-list a {
      color: rgba(0, 0, 0, 0.87);
    }
    
    mat-nav-list a.active {
      background-color: rgba(63, 81, 181, 0.15);
      color: #3f51b5;
    }
    
    mat-nav-list mat-icon {
      margin-right: 10px;
    }
  `]
})
export class AdminDashboardComponent implements OnInit, OnDestroy {
  isAdmin = false;
  private subscription = new Subscription();

  constructor(
    public adminService: AdminService,
    public router: Router
  ) {}

  ngOnInit(): void {
    this.subscription.add(
      this.adminService.isAdmin$.subscribe(isAdmin => {
        this.isAdmin = isAdmin;
        if (!isAdmin) {
          // If not admin, check if there's a user in localStorage
          const user = localStorage.getItem('currentUser');
          if (!user) {
            this.router.navigate(['/admin/login']);
          }
        }
      })
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  navigateToLogin(): void {
    this.router.navigate(['/admin/login']);
  }
  
  logout(): void {
    this.adminService.logout();
    this.router.navigate(['/admin/login']);
  }
}