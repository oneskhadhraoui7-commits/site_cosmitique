import { Routes } from '@angular/router';
import { AdminLayoutComponent } from './components/admin-layout/admin-layout.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { AdminGuard } from '../../core/guards/admin.guard';
import { ProductManagementComponent } from './components/product-management/product-management.component';

export const AdminRoutes: Routes = [
  {
    path: 'admin',
    component: AdminLayoutComponent,
    children: [
      {
        path: 'login',
        component: AdminLoginComponent
      },
      {
        path: 'dashboard',
        component: AdminDashboardComponent,
        canActivate: [AdminGuard]
      },
      {
        path: 'products',
        component: ProductManagementComponent,
        canActivate: [AdminGuard]
      },
      { 
        path: '', 
        redirectTo: 'dashboard', 
        pathMatch: 'full' 
      },
      { 
        path: '**', 
        redirectTo: 'dashboard' 
      }
    ]
  }
];
