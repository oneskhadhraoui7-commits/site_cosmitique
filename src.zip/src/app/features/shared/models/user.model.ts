// src/app/features/shared/models/user.model.ts
export interface User {
  id: string;
  email: string;
  name: string;
  password: string;
  role: 'user' | 'admin';
  createdAt?: Date;
  // Add other user properties as needed
}