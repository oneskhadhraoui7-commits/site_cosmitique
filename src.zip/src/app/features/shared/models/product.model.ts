// src/app/shared/models/product.model.ts
export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  rating: number;
  reviewCount: number;
  category: string;
  inStock: boolean;  // This is the missing property
}


export interface CartItem {
  id: string;           // Cart item ID
  productId: string;    // Reference to the original product
  quantity: number;
  // Flattened product details
  name: string;
  price: number;
  image: string;
  inStock: boolean;     // Add this to match Product interface
  // Optional product details
  description?: string;
  rating?: number;
  reviewCount?: number;
  category?: string;
}