import { Component } from '@angular/core';

@Component({
  selector: 'app-about-page',
  imports: [],
  template: `
    <p>
      about-page works!
    </p>
  `,
  styles: ``,
})
export class AboutPage {

}
