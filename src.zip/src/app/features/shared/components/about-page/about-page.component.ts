import { Component } from '@angular/core';

@Component({
  selector: 'app-about-page',
  template: `
    <div class="container mx-auto px-4 py-12">
      <h1 class="text-3xl font-bold text-gray-900 mb-8">À propos de nous</h1>
      <div class="prose max-w-3xl">
        <p class="text-lg text-gray-700 mb-4">
          Bienvenue sur notre boutique en ligne de cosmétiques, votre destination de confiance pour des produits de beauté de qualité.
        </p>
        <p class="text-gray-600 mb-6">
          Notre mission est de vous offrir une sélection soigneusement choisie de produits cosmétiques naturels et efficaces,
          tout en fournissant un service client exceptionnel.
        </p>
        <h2 class="text-2xl font-semibold text-gray-800 mt-8 mb-4">Notre engagement</h2>
        <ul class="list-disc pl-5 space-y-2 text-gray-600">
          <li>Des ingrédients naturels et de qualité</li>
          <li>Des produits testés dermatologiquement</li>
          <li>Emballages écologiques</li>
          <li>Sans cruauté envers les animaux</li>
        </ul>
      </div>
    </div>
  `,
  styles: []
})
export class AboutPageComponent {}
