import { Routes } from '@angular/router';
import { AboutPageComponent } from './components/about-page/about-page.component';

export const AboutRoutes: Routes = [
  { path: 'about', component: AboutPageComponent }
];
