import { Routes } from '@angular/router';
import { AuthPageComponent } from './components/auth-page/auth-page.component';

export const AuthRoutes: Routes = [
  { path: 'auth', component: AuthPageComponent }
];