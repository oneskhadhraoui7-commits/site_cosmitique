// auth-page.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../../core/services/auth.service';
import { Router } from '@angular/router';
import { catchError, finalize } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-auth-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './auth-page.component.html',
  styleUrls: ['./auth-page.component.css']
})
export class AuthPageComponent implements OnInit {
  authForm: FormGroup;
  isSignInMode = true;
  isLoading = false;
  error: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.authForm = this.fb.group({
      name: ['', this.isSignInMode ? [] : [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  ngOnInit(): void {
    this.toggleAuthMode();
  }

  toggleAuthMode(): void {
    this.isSignInMode = !this.isSignInMode;
    this.error = null;
    
    // Update validators based on auth mode
    const nameControl = this.authForm.get('name');
    if (this.isSignInMode) {
      nameControl?.clearValidators();
    } else {
      nameControl?.setValidators([Validators.required, Validators.minLength(3)]);
    }
    nameControl?.updateValueAndValidity();
  }

  onSubmit(): void {
    if (this.authForm.invalid || this.isLoading) {
      return;
    }

    this.isLoading = true;
    this.error = null;
    
    const { name, email, password } = this.authForm.value;

    const authAction = this.isSignInMode
      ? this.authService.login(email, password)
      : this.authService.signup(name, email, password);

    authAction.pipe(
      catchError(error => {
        this.error = error.message || 'Une erreur est survenue';
        return of(false);
      }),
      finalize(() => {
        this.isLoading = false;
      })
    ).subscribe(success => {
      if (success) {
        this.router.navigate(['/']);
      }
    });
  }
}