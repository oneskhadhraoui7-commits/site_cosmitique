import { Injectable } from '@angular/core';
import { CanActivate, Router, UrlTree } from '@angular/router';
import { Observable, map } from 'rxjs';
import { AdminService } from '../../../core/services/admin.service';

@Injectable({
  providedIn: 'root'
})
export class AdminAuthGuard implements CanActivate {
  constructor(
    private adminService: AdminService,
    private router: Router
  ) {}

  canActivate(): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return this.adminService.isAdmin$.pipe(
      map(isAdmin => {
        if (isAdmin) {
          return true;
        } else {
          return this.router.createUrlTree(['/admin/login']);
        }
      })
    );
  }
}
