import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ProductsService } from '../../../../core/services/products.service';
import { ProductCardComponent } from '../../../products/components/product-card/product-card.component';
import { map } from 'rxjs/operators';
import { Product } from '../../../../features/shared/models/product.model';

@Component({
  selector: 'app-home-page',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule, 
    RouterLink, 
    ProductCardComponent
  ],
  template: `
    <div class="container mx-auto px-4 py-8">
      <!-- Hero Section -->
      <div class="bg-gradient-to-r from-pink-50 to-purple-50 rounded-2xl p-8 mb-12">
        <div class="max-w-3xl mx-auto text-center">
          <h1 class="text-4xl font-bold text-gray-900 mb-4">Découvrez la beauté naturelle</h1>
          <p class="text-xl text-gray-600 mb-8">Des produits de soin bio et éco-responsables pour une peau éclatante</p>
          <a routerLink="/products" class="bg-pink-600 hover:bg-pink-700 text-white font-semibold px-8 py-3 rounded-full transition duration-300 inline-block">
            Explorer la collection
          </a>
        </div>
      </div>

      <!-- Features Section -->
      <div class="grid md:grid-cols-3 gap-8 mb-16">
        <div class="text-center">
          <div class="bg-pink-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-pink-600">
              <rect x="1" y="3" width="15" height="13"></rect>
              <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
              <circle cx="5.5" cy="18.5" r="2.5"></circle>
              <circle cx="18.5" cy="18.5" r="2.5"></circle>
            </svg>
          </div>
          <h3 class="font-semibold text-lg mb-2">Livraison Gratuite</h3>
          <p class="text-gray-600">Dès 50€ d'achat</p>
        </div>
        <div class="text-center">
          <div class="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-purple-600">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
            </svg>
          </div>
          <h3 class="font-semibold text-lg mb-2">Produits Certifiés</h3>
          <p class="text-gray-600">Qualité garantie</p>
        </div>
        <div class="text-center">
          <div class="bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-indigo-600">
              <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
              <line x1="1" y1="10" x2="23" y2="10"></line>
            </svg>
          </div>
          <h3 class="font-semibold text-lg mb-2">Paiement Sécurisé</h3>
          <p class="text-gray-600">CB, PayPal, Virement</p>
        </div>
      </div>

      <!-- Featured Products -->
      <div class="mb-16">
        <h2 class="text-2xl font-bold text-gray-900 mb-8">Nos Produits Phares</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <app-product-card *ngFor="let product of popularProducts" [product]="product"></app-product-card>
        </div>
      </div>

      <!-- CTA Section -->
      <div class="bg-gradient-to-r from-pink-500 to-purple-600 rounded-2xl p-8 text-white text-center">
        <h2 class="text-2xl font-bold mb-4">Rejoignez notre communauté</h2>
        <p class="mb-6 max-w-2xl mx-auto">Inscrivez-vous à notre newsletter pour recevoir des offres exclusives et des conseils beauté personnalisés.</p>
        <div class="max-w-md mx-auto flex">
          <input type="email" placeholder="Votre adresse email" class="flex-grow px-4 py-3 rounded-l-lg focus:outline-none text-gray-900">
          <button class="bg-white text-pink-600 font-semibold px-6 py-3 rounded-r-lg hover:bg-gray-100 transition duration-300">
            S'inscrire
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class HomePageComponent implements OnInit {
  popularProducts: Product[] = [];

  constructor(
    private productsService: ProductsService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.loadProducts();
  }

  private loadProducts(): void {
    this.productsService.getProducts().pipe(
      map(products => products.slice(0, 4))
    ).subscribe({
      next: (products) => {
        this.popularProducts = products;
        this.cdr.markForCheck();
      },
      error: (error) => {
        console.error('Error loading popular products:', error);
        this.popularProducts = [];
        this.cdr.markForCheck();
      }
    });
  }
}