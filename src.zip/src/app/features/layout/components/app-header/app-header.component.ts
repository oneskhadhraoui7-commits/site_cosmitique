import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { LucideAngularModule, Menu, X as Close, Search, Heart, ShoppingCart as Cart, LogOut, User as UserIcon, Sparkles } from 'lucide-angular';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthService } from '../../../../core/services/auth.service';
import { CartService } from '../../../../core/services/cart.service';
import { FavoritesService } from '../../../../core/services/favorites.service';
import { User } from '../../../shared/models/user.model';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, LucideAngularModule],
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.css']
})
export class AppHeaderComponent implements OnInit {
  // Icons
  icons = {
    menu: Menu,
    close: Close,
    search: Search,
    heart: Heart,
    cart: Cart,
    user: UserIcon,
    sparkles: Sparkles,
    logout: LogOut
  };
  
  isMenuOpen = false;
  isUserMenuOpen = false;
  user$: Observable<User | null>;

  constructor(
    private authService: AuthService,
    private router: Router,
    private cartService: CartService,
    private favoritesService: FavoritesService
  ) {
    this.user$ = this.authService.user$;
  }

  ngOnInit(): void {
    this.authService.autoLogin();
  }

  toggleMenu(): void {
    this.isMenuOpen = !this.isMenuOpen;
  }

  toggleUserMenu(): void {
    this.isUserMenuOpen = !this.isUserMenuOpen;
  }

  closeUserMenu(): void {
    this.isUserMenuOpen = false;
  }

  logout(): void {
    this.authService.logout();
    this.isUserMenuOpen = false;
    this.router.navigate(['/auth']);
  }

  navigateToAuth(): void {
    this.router.navigate(['/auth']);
  }

  // Getters for cart and favorites count
  get cartCount$(): Observable<number> {
    return this.cartService.cart$.pipe(
      map(cartItems => cartItems?.length || 0)
    );
  }

  get favoritesCount$(): Observable<number> {
    return this.favoritesService.favorites$.pipe(
      map(favorites => favorites?.length || 0)
    );
  }
}