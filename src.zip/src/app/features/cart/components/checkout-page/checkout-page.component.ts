import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { CartService } from '../../../../core/services/cart.service';
import { CartItem } from '../../../shared/models/product.model';
import { take } from 'rxjs/operators'; // Add this import

@Component({
  selector: 'app-checkout-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './checkout-page.component.html',
  styleUrls: ['./checkout-page.component.css']
})
export class CheckoutPageComponent {
  checkoutForm: FormGroup;
  cart$: Observable<CartItem[]>;
  total$: Observable<number>;

  constructor(
    private fb: FormBuilder,
    private cartService: CartService,
    private router: Router
  ) {
    this.checkoutForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      name: ['', Validators.required],
      address: ['', Validators.required],
      city: ['', Validators.required],
      postalCode: ['', Validators.required],
      cardNumber: ['', Validators.required],
      expiry: ['', Validators.required],
      cvv: ['', Validators.required]
    });

    this.cart$ = this.cartService.cart$;
    this.total$ = this.cart$.pipe(
      map(cart => this.cartService.getTotal())
    );
  }

  onSubmit(): void {
    if (this.checkoutForm.valid) {
      alert('Commande validée ! Merci pour votre achat 🎉');
      this.cartService.cart$.pipe(take(1)).subscribe(cart => {
        // You might want to save the order to a database here
        this.cartService.clearCart();
        this.router.navigate(['/home']);
      });
    } else {
      alert('Veuillez remplir tous les champs correctement.');
    }
  }
}