// src/app/features/cart/components/cart-page/cart-page.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { LucideAngularModule, Trash2, Plus, Minus, ArrowLeft } from 'lucide-angular';
import { CartService } from '../../../../core/services/cart.service';
import { CartItem } from '../../../shared/models/product.model';
import { X } from 'lucide-angular';
@Component({
  selector: 'app-cart-page',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent {
  cart$: Observable<CartItem[]>;
  total$: Observable<number>;

  // Icons
  icons = {
    trash: Trash2,
    plus: Plus,
    minus: Minus,
    arrowLeft: ArrowLeft,
    x: X
  };

  constructor(
    private cartService: CartService,
    private router: Router
  ) {
    this.cart$ = this.cartService.cart$;
    this.total$ = this.cartService.cart$.pipe(
      map(items => this.cartService.getTotal())
    );
  }

  // Update the removeFromCart method in cart-page.component.ts
removeFromCart(cartItemId: string): void {
  this.cartService.removeFromCart(cartItemId);
}

  updateQuantity(item: CartItem, change: number): void {
    const newQuantity = (item.quantity || 1) + change;
    if (newQuantity > 0) {
      this.cartService.updateQuantity(item.id, newQuantity);
    } else {
      this.removeFromCart(item.id);
    }
  }

  continueShopping(): void {
    this.router.navigate(['/products']);
  }

  // Add this method to handle checkout
  proceedToCheckout(): void {
    this.router.navigate(['/checkout']);
  }
}