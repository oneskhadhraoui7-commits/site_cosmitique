import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideAnimations } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { routes } from './app.routes';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';

import { MatNativeDateModule } from '@angular/material/core';

import { LucideAngularModule } from 'lucide-angular';
import { 
  Heart, 
  ShoppingCart, 
  Star,
  StarHalf,
  StarIcon,
  HeartIcon,
  ShoppingCartIcon
} from 'lucide-angular';

const lucideIcons = {
  Heart,
  HeartIcon,
  ShoppingCart,
  ShoppingCartIcon,
  Star,
  StarHalf,
  StarIcon
};

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideAnimations(),
    provideHttpClient(withInterceptorsFromDi()),
    importProvidersFrom(
      FormsModule,
      ReactiveFormsModule,
      MatNativeDateModule,
      LucideAngularModule.pick(lucideIcons)
    )
  ]
};