export interface User {
  id: string;
  email: string;
  name?: string;
  createdAt?: Date | string;
  // Add other user properties as needed
}
