// auth.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of, throwError } from 'rxjs';
import { catchError, tap, map, switchMap } from 'rxjs/operators';
import { User } from '../../features/shared/models/user.model';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { v4 as uuidv4 } from 'uuid';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private userSubject = new BehaviorSubject<User | null>(null);
  user$: Observable<User | null> = this.userSubject.asObservable();
  private readonly API_URL = `${environment.apiUrl}/users`;

  constructor(
    private router: Router,
    private http: HttpClient
  ) {
    // Load user from localStorage if exists
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      this.userSubject.next(JSON.parse(storedUser));
    }
  }

  getCurrentUser(): User | null {
    return this.userSubject.value;
  }

  login(email: string, password: string): Observable<boolean> {
    return this.http.get<User[]>(`${this.API_URL}?email=${email}&password=${password}`).pipe(
      map(users => {
        const user = users[0];
        if (user) {
          this.userSubject.next(user);
          localStorage.setItem('currentUser', JSON.stringify(user));
          return true;
        }
        throw new Error('Email ou mot de passe incorrect');
      })
    );
  }

  signup(name: string, email: string, password: string, role: 'user' | 'admin' = 'user'): Observable<boolean> {
    // Check if user already exists
    return this.http.get<User[]>(`${this.API_URL}?email=${email}`).pipe(
      switchMap(users => {
        if (users && users.length > 0) {
          return throwError(() => new Error('Un compte existe déjà avec cet email'));
        }

        const newUser: User = {
          id: uuidv4(),
          name,
          email,
          password,
          role
        };

        return this.http.post<User>(this.API_URL, newUser).pipe(
          tap(user => {
            this.userSubject.next(user);
            localStorage.setItem('currentUser', JSON.stringify(user));
          }),
          map(() => true)
        );
      })
    );
  }

  logout(): void {
    this.userSubject.next(null);
    localStorage.removeItem('currentUser');
    this.router.navigate(['/auth']);
  }

  autoLogin(): void {
    const userJson = localStorage.getItem('currentUser');
    if (userJson) {
      const user = JSON.parse(userJson);
      this.userSubject.next(user);
    }
  }

  isAuthenticated(): boolean {
    return !!this.userSubject.value;
  }

  // Helper method to get user ID
  getUserId(): string | null {
    return this.userSubject.value?.id || null;
  }
}