// src/app/core/services/mock-backend.service.ts
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MockBackendService {
  private cartItems: any[] = [];
  private favorites: any[] = [];

  // Mock cart methods
  getCart(userId: string): Observable<any[]> {
    return of(this.cartItems.filter(item => item.userId === userId));
  }

  addToCart(item: any): Observable<any> {
    this.cartItems.push(item);
    return of(item);
  }

  // Mock favorites methods
  getFavorites(userId: string): Observable<any[]> {
    return of(this.favorites.filter(fav => fav.userId === userId));
  }

  addToFavorites(item: any): Observable<any> {
    this.favorites.push(item);
    return of(item);
  }
}