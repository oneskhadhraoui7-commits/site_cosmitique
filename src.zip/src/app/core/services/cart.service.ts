// src/app/core/services/cart.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { CartItem } from '../../features/shared/models/product.model';  // If you have this
import { Product } from '../../shared/models/product.model';     // Update this import
import { AuthService } from './auth.service';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { switchMap, map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartSubject = new BehaviorSubject<CartItem[]>([]);
  cart$ = this.cartSubject.asObservable();
  private readonly apiUrl = `${environment.apiUrl}/cart`;

  constructor(
    private authService: AuthService,
    private http: HttpClient
  ) {
    this.loadInitialCart();
  }

  private loadInitialCart(): void {
    this.authService.user$.pipe(
      switchMap(user => {
        if (user) {
          return this.getUserCart(user.id);
        }
        return of([]);
      })
    ).subscribe(cart => {
      this.cartSubject.next(cart);
    });
  }

  private getUserCart(userId: string): Observable<CartItem[]> {
    return this.http.get<CartItem[]>(`${this.apiUrl}?userId=${userId}`).pipe(
      map(items => items.map(item => ({
        ...item,
        id: item.id,
        productId: item.productId,
        quantity: item.quantity,
        name: item.name,
        price: item.price,
        image: item.image
      }))),
      catchError(error => {
        console.error('Error fetching cart:', error);
        return of([]);
      })
    );
  }

  addToCart(product: Product): void {
    const user = this.authService.getCurrentUser();
    if (!user) {
      console.warn('User not logged in');
      return;
    }

    const current = this.cartSubject.value;
    const existingItem = current.find(i => i.productId === product.id);
    
    if (existingItem) {
      // If item already exists in cart, increment quantity
      const updatedItem = { 
        ...existingItem, 
        quantity: existingItem.quantity + 1 
      };
      
      this.http.patch<CartItem>(
        `${this.apiUrl}/${existingItem.id}`, 
        { quantity: updatedItem.quantity }
      ).subscribe({
        next: () => {
          const updatedCart = current.map(item => 
            item.id === existingItem.id ? updatedItem : item
          );
          this.cartSubject.next(updatedCart);
        },
        error: (error) => console.error('Error updating cart item:', error)
      });
    } else {
      // Add new item to cart
      const newItem: Omit<CartItem, 'id'> = {
        productId: product.id,
        quantity: 1,
        name: product.name,
        price: product.price,
        image: product.image,
        inStock: product.inStock,
        description: product.description,
        rating: product.rating,
        reviewCount: product.reviewCount,
        category: product.category
      };
      
      this.http.post<CartItem>(this.apiUrl, newItem).subscribe({
        next: (savedItem) => {
          this.cartSubject.next([...current, savedItem]);
        },
        error: (error) => console.error('Error adding to cart:', error)
      });
    }
  }


  getCart(userId: string): Observable<any[]> {
    return this.http.get<any[]>(`${environment.apiUrl}/cart?userId=${userId}`);
  }
  
  removeFromCart(cartItemId: string): void {
    const user = this.authService.getCurrentUser();
    if (!user) {
      console.warn('User not logged in');
      return;
    }

    const current = this.cartSubject.value;
    this.http.delete(`${this.apiUrl}/${cartItemId}`).subscribe({
      next: () => {
        this.cartSubject.next(current.filter(item => item.id !== cartItemId));
      },
      error: (error) => {
        console.error('Error removing from cart:', error);
      }
    });
  }

  updateQuantity(cartItemId: string, quantity: number): void {
    const user = this.authService.getCurrentUser();
    if (!user) {
      console.warn('User not logged in');
      return;
    }

    const current = [...this.cartSubject.value];
    const itemIndex = current.findIndex(i => i.id === cartItemId);
    
    if (itemIndex > -1) {
      const originalQuantity = current[itemIndex].quantity;
      current[itemIndex] = { ...current[itemIndex], quantity };
      
      this.http.patch<CartItem>(`${this.apiUrl}/${cartItemId}`, { quantity })
        .subscribe({
          next: () => {
            this.cartSubject.next([...current]);
          },
          error: (error) => {
            console.error('Error updating cart item:', error);
            // Revert the quantity change on error
            current[itemIndex] = { ...current[itemIndex], quantity: originalQuantity };
            this.cartSubject.next([...current]);
          }
        });
    }
  }

  clearCart(): void {
    const user = this.authService.getCurrentUser();
    if (!user) {
      console.warn('User not logged in');
      return;
    }

    this.http.delete(`${this.apiUrl}/clear/${user.id}`).subscribe(() => {
      this.cartSubject.next([]);
    });
  }

  getTotal(): number {
    return this.cartSubject.value.reduce(
      (total: number, item: CartItem) => total + (item.price * (item.quantity || 1)),
      0
    );
  }
}