// src/app/core/services/products.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { tap, catchError, map } from 'rxjs/operators';
import { Product } from '../../features/shared/models/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  private apiUrl = 'http://localhost:3000';
  private products: Product[] = [];

  constructor(private http: HttpClient) {
    // Load products from the server when service initializes
    this.loadProducts();
  }

  loadProducts(): void {
    this.getProducts().subscribe(products => {
      this.products = products;
    }, error => {
      console.error('Error loading products:', error);
    });
  }

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.apiUrl}/products`).pipe(
      tap(products => console.log('Fetched products:', products)),
      catchError(error => {
        console.error('Error fetching products:', error);
        return of([]);
      })
    );
  }

  getProductList(): Product[] {
    return [...this.products];
  }

  getProductById(id: string): Observable<Product | undefined> {
    return this.http.get<Product>(`${this.apiUrl}/products/${id}`).pipe(
      catchError(error => {
        console.error(`Error fetching product with id ${id}:`, error);
        return of(undefined);
      })
    );
  }

  addProduct(product: Omit<Product, 'id'>): Observable<Product> {
    return this.http.post<Product>(`${this.apiUrl}/products`, product).pipe(
      tap(newProduct => {
        this.products.push(newProduct);
        console.log('Added product:', newProduct);
      }),
      catchError(error => {
        console.error('Error adding product:', error);
        throw error;
      })
    );
  }

  updateProduct(id: string, updatedProduct: Partial<Product>): Observable<Product> {
    return this.http.patch<Product>(`${this.apiUrl}/products/${id}`, updatedProduct).pipe(
      tap(product => {
        const index = this.products.findIndex(p => p.id === id);
        if (index !== -1) {
          this.products[index] = { ...this.products[index], ...updatedProduct };
          console.log('Updated product:', product);
        }
      }),
      catchError(error => {
        console.error(`Error updating product with id ${id}:`, error);
        throw error;
      })
    );
  }

  deleteProduct(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/products/${id}`).pipe(
      tap(() => {
        const index = this.products.findIndex(p => p.id === id);
        if (index !== -1) {
          this.products.splice(index, 1);
          console.log('Deleted product with id:', id);
        }
      }),
      catchError(error => {
        console.error(`Error deleting product with id ${id}:`, error);
        throw error;
      })
    );
  }
}