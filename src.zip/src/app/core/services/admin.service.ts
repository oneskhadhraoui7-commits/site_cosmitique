import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { catchError, map, tap } from 'rxjs/operators';
import { User } from '../../features/shared/models/user.model';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private isAdminSubject = new BehaviorSubject<boolean>(false);
  private apiUrl = environment.apiUrl;

  get isAdmin$(): Observable<boolean> {
    return this.isAdminSubject.asObservable();
  }

  constructor(private http: HttpClient) {
    this.checkAdminStatus();
  }

  checkAdminStatus(): void {
    const userJson = localStorage.getItem('currentUser');
    if (userJson) {
      const user: User = JSON.parse(userJson);
      this.isAdminSubject.next(user.role === 'admin');
    } else {
      this.isAdminSubject.next(false);
    }
  }

  login(email: string, password: string): Observable<boolean> {
    const url = `${this.apiUrl}/users?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}&role=admin`;
    
    return this.http.get<User[]>(url).pipe(
      map(users => {
        const user = users[0];
        if (user && user.role === 'admin') {
          try {
            localStorage.setItem('currentUser', JSON.stringify(user));
            this.isAdminSubject.next(true);
            return true;
          } catch (e) {
            console.error('Error storing admin session:', e);
            return false;
          }
        }
        console.log('Admin login failed - invalid credentials or not an admin');
        return false;
      }),
      catchError(error => {
        console.error('Error during admin login:', error);
        return of(false);
      })
    );
  }

  logout(): void {
    this.isAdminSubject.next(false);
  }
}