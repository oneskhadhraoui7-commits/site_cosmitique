// src/app/core/services/favorites.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { Product } from '../../features/shared/models/product.model';
import { AuthService } from './auth.service';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { switchMap, tap } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FavoritesService {
  private favoritesSubject = new BehaviorSubject<Product[]>([]);
  favorites$ = this.favoritesSubject.asObservable();
  private readonly apiUrl = `${environment.apiUrl}/favorites`;

  constructor(
    private authService: AuthService,
    private http: HttpClient
  ) {
    this.loadInitialFavorites();
  }

  private loadInitialFavorites(): void {
    const user = this.authService.getCurrentUser();
    if (user) {
      this.getUserFavorites(user.id).subscribe(favorites => {
        this.favoritesSubject.next(favorites);
      });
    } else {
      this.favoritesSubject.next([]);
    }
  }

  
  private getUserFavorites(userId: string): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.apiUrl}?userId=${userId}`);
  }

  addToFavorites(product: Product): void {
  const user = this.authService.getCurrentUser();
  if (!user) {
    console.warn('User not logged in');
    return;
  }

  const current = this.favoritesSubject.value;
  if (current.some(p => p.id === product.id)) {
    return;
  }

  this.http.post(this.apiUrl, { userId: user.id, productId: product.id }).pipe(
    tap(() => {
      this.favoritesSubject.next([...current, product]);
    })
  ).subscribe();
}

  getFavorites(userId: string): Observable<any[]> {
  return this.http.get<any[]>(`${environment.apiUrl}/favorites?userId=${userId}`);
}

removeFromFavorites(productId: string): Observable<any> {
  const user = this.authService.getCurrentUser();
  if (!user) {
    return throwError(() => new Error('User not authenticated'));
  }
  
  // First find the favorite ID to delete
  return this.http.get<any[]>(`${this.apiUrl}?userId=${user.id}&productId=${productId}`).pipe(
    switchMap(favorites => {
      if (favorites && favorites.length > 0) {
        const favoriteId = favorites[0].id;
        return this.http.delete(`${this.apiUrl}/${favoriteId}`).pipe(
          tap(() => {
            // Update the local state after successful deletion
            const current = this.favoritesSubject.value;
            this.favoritesSubject.next(current.filter(p => p.id !== productId));
          })
        );
      }
      // If favorite not found, just complete the observable without error
      // since the desired end state (favorite removed) is already achieved
      return of(null);
    })
  );
}

  isFavorite(productId: string): boolean {
    return this.favoritesSubject.value.some(p => p.id === productId);
  }
}