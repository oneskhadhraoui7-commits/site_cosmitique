import { Routes } from '@angular/router';
import { AuthRoutes } from './features/auth/auth.routes';
import { CartRoutes } from './features/cart/cart.routes';
import { HomeRoutes } from './features/home/home.routes';
import { ProductsRoutes } from './features/products/products.routes';
import { MainLayoutComponent } from './features/layout/components/main-layout/main-layout.component';
import { AboutRoutes } from './features/shared/about.routes';
import { AccountRoutes } from './features/account/account.routes';
import { FavoritesRoutes } from './features/favorites/favorites.routes';
import { AdminRoutes } from './features/admin/admin.routes';

export const routes: Routes = [
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      ...HomeRoutes,
      ...ProductsRoutes,
      ...CartRoutes,
      ...AuthRoutes,
      ...AboutRoutes,
      ...AccountRoutes,
      ...FavoritesRoutes,
      ...AdminRoutes,
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: '**', redirectTo: 'home' }
    ]
  }
];