// src/environments/environment.ts
export const environment = {
  production: false,
  useMockBackend: false, // Set to false since we're using JSON Server
  apiUrl: 'http://localhost:3000' // Remove /api from here
};