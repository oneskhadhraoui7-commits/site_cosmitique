export const environment = {
  production: true,
  apiUrl: 'https://your-production-api-url.com/api' // Update with your production API URL
};
